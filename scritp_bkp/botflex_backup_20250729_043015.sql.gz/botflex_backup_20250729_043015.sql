--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Ubuntu 17.5-1.pgdg22.04+1)
-- Dumped by pg_dump version 17.5 (Ubuntu 17.5-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Announcements; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Announcements" (
    id integer NOT NULL,
    priority integer,
    title character varying(255) NOT NULL,
    text text NOT NULL,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    status boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Announcements" OWNER TO botflex;

--
-- Name: Announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Announcements_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Announcements_id_seq" OWNER TO botflex;

--
-- Name: Announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Announcements_id_seq" OWNED BY public."Announcements".id;


--
-- Name: Baileys; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Baileys" (
    id integer NOT NULL,
    "whatsappId" integer NOT NULL,
    contacts text,
    chats text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Baileys" OWNER TO botflex;

--
-- Name: BaileysChats; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."BaileysChats" (
    id integer NOT NULL,
    "whatsappId" integer,
    jid character varying(255) NOT NULL,
    "conversationTimestamp" character varying(255) NOT NULL,
    "unreadCount" integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."BaileysChats" OWNER TO botflex;

--
-- Name: BaileysChats_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."BaileysChats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."BaileysChats_id_seq" OWNER TO botflex;

--
-- Name: BaileysChats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."BaileysChats_id_seq" OWNED BY public."BaileysChats".id;


--
-- Name: BaileysMessages; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."BaileysMessages" (
    id integer NOT NULL,
    "whatsappId" integer,
    "baileysChatId" integer,
    "jsonMessage" json NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."BaileysMessages" OWNER TO botflex;

--
-- Name: BaileysMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."BaileysMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."BaileysMessages_id_seq" OWNER TO botflex;

--
-- Name: BaileysMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."BaileysMessages_id_seq" OWNED BY public."BaileysMessages".id;


--
-- Name: Baileys_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Baileys_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Baileys_id_seq" OWNER TO botflex;

--
-- Name: Baileys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Baileys_id_seq" OWNED BY public."Baileys".id;


--
-- Name: CampaignSettings; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."CampaignSettings" (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignSettings" OWNER TO botflex;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."CampaignSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CampaignSettings_id_seq" OWNER TO botflex;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."CampaignSettings_id_seq" OWNED BY public."CampaignSettings".id;


--
-- Name: CampaignShipping; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."CampaignShipping" (
    id integer NOT NULL,
    "jobId" character varying(255),
    number character varying(255) NOT NULL,
    message text NOT NULL,
    "confirmationMessage" text,
    confirmation boolean,
    "contactId" integer,
    "campaignId" integer NOT NULL,
    "confirmationRequestedAt" timestamp with time zone,
    "confirmedAt" timestamp with time zone,
    "deliveredAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignShipping" OWNER TO botflex;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."CampaignShipping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CampaignShipping_id_seq" OWNER TO botflex;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."CampaignShipping_id_seq" OWNED BY public."CampaignShipping".id;


--
-- Name: Campaigns; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Campaigns" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message1 text DEFAULT ''::text,
    message2 text DEFAULT ''::text,
    message3 text DEFAULT ''::text,
    message4 text DEFAULT ''::text,
    message5 text DEFAULT ''::text,
    "confirmationMessage1" text DEFAULT ''::text,
    "confirmationMessage2" text DEFAULT ''::text,
    "confirmationMessage3" text DEFAULT ''::text,
    "confirmationMessage4" text DEFAULT ''::text,
    "confirmationMessage5" text DEFAULT ''::text,
    status character varying(255),
    confirmation boolean DEFAULT false,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    "contactListId" integer,
    "whatsappId" integer,
    "scheduledAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "fileListId" integer
);


ALTER TABLE public."Campaigns" OWNER TO botflex;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Campaigns_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Campaigns_id_seq" OWNER TO botflex;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Campaigns_id_seq" OWNED BY public."Campaigns".id;


--
-- Name: ChatMessages; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."ChatMessages" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "senderId" integer NOT NULL,
    message text DEFAULT ''::text,
    "mediaPath" text,
    "mediaName" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatMessages" OWNER TO botflex;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."ChatMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ChatMessages_id_seq" OWNER TO botflex;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."ChatMessages_id_seq" OWNED BY public."ChatMessages".id;


--
-- Name: ChatUsers; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."ChatUsers" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "userId" integer NOT NULL,
    unreads integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatUsers" OWNER TO botflex;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."ChatUsers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ChatUsers_id_seq" OWNER TO botflex;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."ChatUsers_id_seq" OWNED BY public."ChatUsers".id;


--
-- Name: Chats; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Chats" (
    id integer NOT NULL,
    title text DEFAULT ''::text,
    uuid character varying(255) DEFAULT ''::character varying,
    "ownerId" integer NOT NULL,
    "lastMessage" text,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Chats" OWNER TO botflex;

--
-- Name: Chats_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Chats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Chats_id_seq" OWNER TO botflex;

--
-- Name: Chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Chats_id_seq" OWNED BY public."Chats".id;


--
-- Name: Companies; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(255),
    email character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "planId" integer,
    status boolean DEFAULT true,
    schedules jsonb DEFAULT '[]'::jsonb,
    "dueDate" timestamp with time zone,
    recurrence character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."Companies" OWNER TO botflex;

--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Companies_id_seq" OWNER TO botflex;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: ContactCustomFields; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."ContactCustomFields" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    "contactId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactCustomFields" OWNER TO botflex;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."ContactCustomFields_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactCustomFields_id_seq" OWNER TO botflex;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."ContactCustomFields_id_seq" OWNED BY public."ContactCustomFields".id;


--
-- Name: ContactListItems; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."ContactListItems" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    email character varying(255),
    "contactListId" integer NOT NULL,
    "isWhatsappValid" boolean DEFAULT false,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactListItems" OWNER TO botflex;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."ContactListItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactListItems_id_seq" OWNER TO botflex;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."ContactListItems_id_seq" OWNED BY public."ContactListItems".id;


--
-- Name: ContactLists; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."ContactLists" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactLists" OWNER TO botflex;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."ContactLists_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactLists_id_seq" OWNER TO botflex;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."ContactLists_id_seq" OWNED BY public."ContactLists".id;


--
-- Name: Contacts; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Contacts" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    "profilePicUrl" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    "isGroup" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    active boolean DEFAULT true,
    "whatsappId" integer,
    "disableBot" boolean DEFAULT false
);


ALTER TABLE public."Contacts" OWNER TO botflex;

--
-- Name: Contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Contacts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Contacts_id_seq" OWNER TO botflex;

--
-- Name: Contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Contacts_id_seq" OWNED BY public."Contacts".id;


--
-- Name: Files; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Files" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Files" OWNER TO botflex;

--
-- Name: FilesOptions; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."FilesOptions" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    "fileId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaType" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."FilesOptions" OWNER TO botflex;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."FilesOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FilesOptions_id_seq" OWNER TO botflex;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."FilesOptions_id_seq" OWNED BY public."FilesOptions".id;


--
-- Name: Files_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Files_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Files_id_seq" OWNER TO botflex;

--
-- Name: Files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Files_id_seq" OWNED BY public."Files".id;


--
-- Name: Helps; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Helps" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video character varying(255),
    link text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Helps" OWNER TO botflex;

--
-- Name: Helps_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Helps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Helps_id_seq" OWNER TO botflex;

--
-- Name: Helps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Helps_id_seq" OWNED BY public."Helps".id;


--
-- Name: Invoices; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Invoices" (
    id integer NOT NULL,
    detail character varying(255),
    status character varying(255),
    value double precision,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "dueDate" character varying(255),
    "companyId" integer
);


ALTER TABLE public."Invoices" OWNER TO botflex;

--
-- Name: Invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Invoices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Invoices_id_seq" OWNER TO botflex;

--
-- Name: Invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Invoices_id_seq" OWNED BY public."Invoices".id;


--
-- Name: Messages; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Messages" (
    id character varying(255) NOT NULL,
    body text NOT NULL,
    ack integer DEFAULT 0 NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "mediaType" character varying(255),
    "mediaUrl" character varying(255),
    "ticketId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "fromMe" boolean DEFAULT false NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "contactId" integer,
    "quotedMsgId" character varying(255),
    "companyId" integer,
    "remoteJid" text,
    "dataJson" text,
    participant text,
    "queueId" integer,
    "isEdited" boolean DEFAULT false,
    reactions json DEFAULT '[]'::json,
    "isForwarded" boolean DEFAULT false
);


ALTER TABLE public."Messages" OWNER TO botflex;

--
-- Name: Plans; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Plans" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    users integer DEFAULT 0,
    connections integer DEFAULT 0,
    queues integer DEFAULT 0,
    value double precision DEFAULT '0'::double precision,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "useCampaigns" boolean DEFAULT true,
    "useExternalApi" boolean DEFAULT true,
    "useInternalChat" boolean DEFAULT true,
    "useSchedules" boolean DEFAULT true,
    "useInternal" boolean DEFAULT true,
    "useKanban" boolean DEFAULT true,
    "useOpenAi" boolean DEFAULT true,
    "useIntegrations" boolean DEFAULT true
);


ALTER TABLE public."Plans" OWNER TO botflex;

--
-- Name: Plans_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Plans_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Plans_id_seq" OWNER TO botflex;

--
-- Name: Plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Plans_id_seq" OWNED BY public."Plans".id;


--
-- Name: Prompts; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Prompts" (
    id integer NOT NULL,
    name text NOT NULL,
    "apiKey" text NOT NULL,
    prompt text NOT NULL,
    "maxTokens" integer DEFAULT 100 NOT NULL,
    "maxMessages" integer DEFAULT 10 NOT NULL,
    temperature integer DEFAULT 1 NOT NULL,
    "promptTokens" integer DEFAULT 0 NOT NULL,
    "completionTokens" integer DEFAULT 0 NOT NULL,
    "totalTokens" integer DEFAULT 0 NOT NULL,
    voice text,
    "voiceKey" text,
    "voiceRegion" text,
    "queueId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Prompts" OWNER TO botflex;

--
-- Name: Prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Prompts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Prompts_id_seq" OWNER TO botflex;

--
-- Name: Prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Prompts_id_seq" OWNED BY public."Prompts".id;


--
-- Name: QueueIntegrations; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."QueueIntegrations" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "projectName" character varying(255) NOT NULL,
    "jsonContent" text NOT NULL,
    language character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "urlN8N" character varying(255) DEFAULT true NOT NULL,
    "companyId" integer,
    "typebotExpires" integer DEFAULT 0 NOT NULL,
    "typebotKeywordFinish" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotSlug" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotUnknownMessage" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotDelayMessage" integer DEFAULT 1000 NOT NULL,
    "typebotKeywordRestart" character varying(255) DEFAULT ''::character varying,
    "typebotRestartMessage" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."QueueIntegrations" OWNER TO botflex;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."QueueIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QueueIntegrations_id_seq" OWNER TO botflex;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."QueueIntegrations_id_seq" OWNED BY public."QueueIntegrations".id;


--
-- Name: QueueOptions; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."QueueOptions" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    option text,
    "queueId" integer,
    "parentId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaName" text DEFAULT ''::text,
    "mediaPath" text DEFAULT ''::text
);


ALTER TABLE public."QueueOptions" OWNER TO botflex;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."QueueOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QueueOptions_id_seq" OWNER TO botflex;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."QueueOptions_id_seq" OWNED BY public."QueueOptions".id;


--
-- Name: Queues; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Queues" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255) NOT NULL,
    "greetingMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    schedules jsonb DEFAULT '[]'::jsonb,
    "outOfHoursMessage" text,
    "orderQueue" integer,
    "mediaName" text DEFAULT ''::text,
    "mediaPath" text DEFAULT ''::text,
    "integrationId" integer,
    "promptId" integer
);


ALTER TABLE public."Queues" OWNER TO botflex;

--
-- Name: Queues_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Queues_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Queues_id_seq" OWNER TO botflex;

--
-- Name: Queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Queues_id_seq" OWNED BY public."Queues".id;


--
-- Name: QuickMessages; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."QuickMessages" (
    id integer NOT NULL,
    shortcode character varying(255) NOT NULL,
    message text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" integer,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    geral boolean DEFAULT false NOT NULL
);


ALTER TABLE public."QuickMessages" OWNER TO botflex;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."QuickMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QuickMessages_id_seq" OWNER TO botflex;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."QuickMessages_id_seq" OWNED BY public."QuickMessages".id;


--
-- Name: Schedules; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Schedules" (
    id integer NOT NULL,
    body text NOT NULL,
    "sendAt" timestamp with time zone,
    "sentAt" timestamp with time zone,
    "contactId" integer,
    "ticketId" integer,
    "userId" integer,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    status character varying(255),
    "queueId" integer,
    "whatsappId" integer,
    geral boolean DEFAULT false NOT NULL,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    "repeatEvery" text,
    "repeatCount" text,
    "selectDaysRecorrenci" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."Schedules" OWNER TO botflex;

--
-- Name: Schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Schedules_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Schedules_id_seq" OWNER TO botflex;

--
-- Name: Schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Schedules_id_seq" OWNED BY public."Schedules".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO botflex;

--
-- Name: Settings; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Settings" (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    id integer NOT NULL
);


ALTER TABLE public."Settings" OWNER TO botflex;

--
-- Name: Settings_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Settings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Settings_id_seq" OWNER TO botflex;

--
-- Name: Settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Settings_id_seq" OWNED BY public."Settings".id;


--
-- Name: Subscriptions; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Subscriptions" (
    id integer NOT NULL,
    "isActive" boolean DEFAULT false,
    "expiresAt" timestamp with time zone NOT NULL,
    "userPriceCents" integer,
    "whatsPriceCents" integer,
    "lastInvoiceUrl" character varying(255),
    "lastPlanChange" timestamp with time zone,
    "companyId" integer,
    "providerSubscriptionId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Subscriptions" OWNER TO botflex;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Subscriptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Subscriptions_id_seq" OWNER TO botflex;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Subscriptions_id_seq" OWNED BY public."Subscriptions".id;


--
-- Name: Tags; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Tags" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255),
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    kanban integer
);


ALTER TABLE public."Tags" OWNER TO botflex;

--
-- Name: Tags_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Tags_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tags_id_seq" OWNER TO botflex;

--
-- Name: Tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Tags_id_seq" OWNED BY public."Tags".id;


--
-- Name: TicketNotes; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."TicketNotes" (
    id integer NOT NULL,
    note character varying(255) NOT NULL,
    "userId" integer,
    "contactId" integer NOT NULL,
    "ticketId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketNotes" OWNER TO botflex;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."TicketNotes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TicketNotes_id_seq" OWNER TO botflex;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."TicketNotes_id_seq" OWNED BY public."TicketNotes".id;


--
-- Name: TicketTags; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."TicketTags" (
    "ticketId" integer NOT NULL,
    "tagId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketTags" OWNER TO botflex;

--
-- Name: TicketTraking; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."TicketTraking" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "whatsappId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "queuedAt" timestamp with time zone,
    "startedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "ratingAt" timestamp with time zone,
    rated boolean DEFAULT false,
    "chatbotAt" timestamp with time zone
);


ALTER TABLE public."TicketTraking" OWNER TO botflex;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."TicketTraking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TicketTraking_id_seq" OWNER TO botflex;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."TicketTraking_id_seq" OWNED BY public."TicketTraking".id;


--
-- Name: Tickets; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Tickets" (
    id integer NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    "lastMessage" text DEFAULT ''::text,
    "contactId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "whatsappId" integer,
    "isGroup" boolean DEFAULT false NOT NULL,
    "unreadMessages" integer,
    "queueId" integer,
    "companyId" integer,
    uuid uuid DEFAULT public.uuid_generate_v4(),
    chatbot boolean DEFAULT false,
    "queueOptionId" integer,
    "amountUsedBotQueues" integer,
    "fromMe" boolean DEFAULT false NOT NULL,
    "useIntegration" boolean DEFAULT false,
    "integrationId" integer,
    "typebotSessionId" character varying(255) DEFAULT NULL::character varying,
    "typebotStatus" boolean DEFAULT false NOT NULL,
    "promptId" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."Tickets" OWNER TO botflex;

--
-- Name: Tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Tickets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tickets_id_seq" OWNER TO botflex;

--
-- Name: Tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Tickets_id_seq" OWNED BY public."Tickets".id;


--
-- Name: UserQueues; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."UserQueues" (
    "userId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."UserQueues" OWNER TO botflex;

--
-- Name: UserRatings; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."UserRatings" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "userId" integer,
    rate integer DEFAULT 0,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public."UserRatings" OWNER TO botflex;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."UserRatings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserRatings_id_seq" OWNER TO botflex;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."UserRatings_id_seq" OWNED BY public."UserRatings".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    profile character varying(255) DEFAULT 'admin'::character varying NOT NULL,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    "companyId" integer,
    super boolean DEFAULT false,
    online boolean DEFAULT false,
    "allTicket" character varying(255) DEFAULT 'desabled'::character varying NOT NULL,
    "whatsappId" integer,
    "resetPassword" character varying(255)
);


ALTER TABLE public."Users" OWNER TO botflex;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_id_seq" OWNER TO botflex;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: WhatsappQueues; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."WhatsappQueues" (
    "whatsappId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."WhatsappQueues" OWNER TO botflex;

--
-- Name: Whatsapps; Type: TABLE; Schema: public; Owner: botflex
--

CREATE TABLE public."Whatsapps" (
    id integer NOT NULL,
    session text,
    qrcode text,
    status character varying(255),
    battery character varying(255),
    plugged boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "greetingMessage" text,
    "companyId" integer,
    "complationMessage" text,
    "outOfHoursMessage" text,
    "ratingMessage" text,
    token text,
    "farewellMessage" text,
    provider text DEFAULT 'stable'::text,
    number text,
    "sendIdQueue" integer,
    "promptId" integer,
    "integrationId" integer,
    "maxUseBotQueues" integer DEFAULT 3,
    "expiresInactiveMessage" character varying(255) DEFAULT ''::character varying,
    "expiresTicket" integer DEFAULT 0,
    "timeUseBotQueues" integer DEFAULT 0,
    "transferQueueId" integer,
    "timeToTransfer" integer
);


ALTER TABLE public."Whatsapps" OWNER TO botflex;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE; Schema: public; Owner: botflex
--

CREATE SEQUENCE public."Whatsapps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Whatsapps_id_seq" OWNER TO botflex;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: botflex
--

ALTER SEQUENCE public."Whatsapps_id_seq" OWNED BY public."Whatsapps".id;


--
-- Name: Announcements id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Announcements" ALTER COLUMN id SET DEFAULT nextval('public."Announcements_id_seq"'::regclass);


--
-- Name: Baileys id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Baileys" ALTER COLUMN id SET DEFAULT nextval('public."Baileys_id_seq"'::regclass);


--
-- Name: BaileysChats id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysChats" ALTER COLUMN id SET DEFAULT nextval('public."BaileysChats_id_seq"'::regclass);


--
-- Name: BaileysMessages id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysMessages" ALTER COLUMN id SET DEFAULT nextval('public."BaileysMessages_id_seq"'::regclass);


--
-- Name: CampaignSettings id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignSettings" ALTER COLUMN id SET DEFAULT nextval('public."CampaignSettings_id_seq"'::regclass);


--
-- Name: CampaignShipping id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignShipping" ALTER COLUMN id SET DEFAULT nextval('public."CampaignShipping_id_seq"'::regclass);


--
-- Name: Campaigns id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns" ALTER COLUMN id SET DEFAULT nextval('public."Campaigns_id_seq"'::regclass);


--
-- Name: ChatMessages id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatMessages" ALTER COLUMN id SET DEFAULT nextval('public."ChatMessages_id_seq"'::regclass);


--
-- Name: ChatUsers id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatUsers" ALTER COLUMN id SET DEFAULT nextval('public."ChatUsers_id_seq"'::regclass);


--
-- Name: Chats id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Chats" ALTER COLUMN id SET DEFAULT nextval('public."Chats_id_seq"'::regclass);


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: ContactCustomFields id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactCustomFields" ALTER COLUMN id SET DEFAULT nextval('public."ContactCustomFields_id_seq"'::regclass);


--
-- Name: ContactListItems id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactListItems" ALTER COLUMN id SET DEFAULT nextval('public."ContactListItems_id_seq"'::regclass);


--
-- Name: ContactLists id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactLists" ALTER COLUMN id SET DEFAULT nextval('public."ContactLists_id_seq"'::regclass);


--
-- Name: Contacts id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Contacts" ALTER COLUMN id SET DEFAULT nextval('public."Contacts_id_seq"'::regclass);


--
-- Name: Files id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Files" ALTER COLUMN id SET DEFAULT nextval('public."Files_id_seq"'::regclass);


--
-- Name: FilesOptions id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."FilesOptions" ALTER COLUMN id SET DEFAULT nextval('public."FilesOptions_id_seq"'::regclass);


--
-- Name: Helps id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Helps" ALTER COLUMN id SET DEFAULT nextval('public."Helps_id_seq"'::regclass);


--
-- Name: Invoices id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Invoices" ALTER COLUMN id SET DEFAULT nextval('public."Invoices_id_seq"'::regclass);


--
-- Name: Plans id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Plans" ALTER COLUMN id SET DEFAULT nextval('public."Plans_id_seq"'::regclass);


--
-- Name: Prompts id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Prompts" ALTER COLUMN id SET DEFAULT nextval('public."Prompts_id_seq"'::regclass);


--
-- Name: QueueIntegrations id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."QueueIntegrations_id_seq"'::regclass);


--
-- Name: QueueOptions id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueOptions" ALTER COLUMN id SET DEFAULT nextval('public."QueueOptions_id_seq"'::regclass);


--
-- Name: Queues id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues" ALTER COLUMN id SET DEFAULT nextval('public."Queues_id_seq"'::regclass);


--
-- Name: QuickMessages id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QuickMessages" ALTER COLUMN id SET DEFAULT nextval('public."QuickMessages_id_seq"'::regclass);


--
-- Name: Schedules id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules" ALTER COLUMN id SET DEFAULT nextval('public."Schedules_id_seq"'::regclass);


--
-- Name: Settings id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Settings" ALTER COLUMN id SET DEFAULT nextval('public."Settings_id_seq"'::regclass);


--
-- Name: Subscriptions id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Subscriptions" ALTER COLUMN id SET DEFAULT nextval('public."Subscriptions_id_seq"'::regclass);


--
-- Name: Tags id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tags" ALTER COLUMN id SET DEFAULT nextval('public."Tags_id_seq"'::regclass);


--
-- Name: TicketNotes id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketNotes" ALTER COLUMN id SET DEFAULT nextval('public."TicketNotes_id_seq"'::regclass);


--
-- Name: TicketTraking id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking" ALTER COLUMN id SET DEFAULT nextval('public."TicketTraking_id_seq"'::regclass);


--
-- Name: Tickets id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets" ALTER COLUMN id SET DEFAULT nextval('public."Tickets_id_seq"'::regclass);


--
-- Name: UserRatings id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserRatings" ALTER COLUMN id SET DEFAULT nextval('public."UserRatings_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: Whatsapps id; Type: DEFAULT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps" ALTER COLUMN id SET DEFAULT nextval('public."Whatsapps_id_seq"'::regclass);


--
-- Data for Name: Announcements; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Announcements" (id, priority, title, text, "mediaPath", "mediaName", "companyId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Baileys; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Baileys" (id, "whatsappId", contacts, chats, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: BaileysChats; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."BaileysChats" (id, "whatsappId", jid, "conversationTimestamp", "unreadCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: BaileysMessages; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."BaileysMessages" (id, "whatsappId", "baileysChatId", "jsonMessage", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignSettings; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."CampaignSettings" (id, key, value, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignShipping; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."CampaignShipping" (id, "jobId", number, message, "confirmationMessage", confirmation, "contactId", "campaignId", "confirmationRequestedAt", "confirmedAt", "deliveredAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Campaigns; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Campaigns" (id, name, message1, message2, message3, message4, message5, "confirmationMessage1", "confirmationMessage2", "confirmationMessage3", "confirmationMessage4", "confirmationMessage5", status, confirmation, "mediaPath", "mediaName", "companyId", "contactListId", "whatsappId", "scheduledAt", "completedAt", "createdAt", "updatedAt", "fileListId") FROM stdin;
\.


--
-- Data for Name: ChatMessages; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."ChatMessages" (id, "chatId", "senderId", message, "mediaPath", "mediaName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatUsers; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."ChatUsers" (id, "chatId", "userId", unreads, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Chats; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Chats" (id, title, uuid, "ownerId", "lastMessage", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Companies" (id, name, phone, email, "createdAt", "updatedAt", "planId", status, schedules, "dueDate", recurrence) FROM stdin;
1	Empresa 1	\N	\N	2025-07-29 09:11:13.305+02	2025-07-29 09:11:13.305+02	1	t	[]	2093-03-14 04:00:00+01	
\.


--
-- Data for Name: ContactCustomFields; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."ContactCustomFields" (id, name, value, "contactId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactListItems; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."ContactListItems" (id, name, number, email, "contactListId", "isWhatsappValid", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactLists; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."ContactLists" (id, name, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Contacts; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Contacts" (id, name, number, "profilePicUrl", "createdAt", "updatedAt", email, "isGroup", "companyId", active, "whatsappId", "disableBot") FROM stdin;
1	Jackson Alves	558299923865	https://pps.whatsapp.net/v/t61.24694-24/491868400_1746598229399762_1723543762510810240_n.jpg?stp=dst-jpg_s96x96_tt6&ccb=11-4&oh=01_Q5Aa2AFkx6GsqnLHMfMRwUCjx8HmzsZQK0yausZVJ799pb2C_w&oe=6895A21A&_nc_sid=5e03e0&_nc_cat=111	2025-07-29 09:24:38.982+02	2025-07-29 09:24:38.982+02		f	1	t	1	f
\.


--
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Files" (id, "companyId", name, message, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FilesOptions; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."FilesOptions" (id, name, path, "fileId", "createdAt", "updatedAt", "mediaType") FROM stdin;
\.


--
-- Data for Name: Helps; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Helps" (id, title, description, video, link, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoices; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Invoices" (id, detail, status, value, "createdAt", "updatedAt", "dueDate", "companyId") FROM stdin;
1	Plano 1	open	30	2025-07-29 09:12:00+02	2025-07-29 09:12:00+02	2093-03-14T00:00:00-03:00	1
\.


--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Messages" (id, body, ack, read, "mediaType", "mediaUrl", "ticketId", "createdAt", "updatedAt", "fromMe", "isDeleted", "contactId", "quotedMsgId", "companyId", "remoteJid", "dataJson", participant, "queueId", "isEdited", reactions, "isForwarded") FROM stdin;
3EB0CB94E36C38E0BB75D9	oi	0	t	conversation	\N	1	2025-07-29 09:24:39.035+02	2025-07-29 09:24:52.303+02	f	f	1	\N	1	558299923865@s.whatsapp.net	{"key":{"remoteJid":"558299923865@s.whatsapp.net","fromMe":false,"id":"3EB0CB94E36C38E0BB75D9"},"messageTimestamp":1753773878,"pushName":"Jackson Alves","broadcast":false,"message":{"conversation":"oi","messageContextInfo":{"deviceListMetadata":{"senderKeyHash":"qKWVIWxyXOf+4A==","senderTimestamp":"1753073640","senderAccountType":"E2EE","receiverAccountType":"E2EE","recipientKeyHash":"R13yL9ICxxjZ8A==","recipientTimestamp":"1752875317"},"deviceListMetadataVersion":2,"messageSecret":"5xrBP8Ro1VFGP6PYzpIwwKdc4eUc1IrIa/44hSgYmsk="}},"verifiedBizName":"Jackson Alves"}	\N	\N	f	[]	f
\.


--
-- Data for Name: Plans; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Plans" (id, name, users, connections, queues, value, "createdAt", "updatedAt", "useCampaigns", "useExternalApi", "useInternalChat", "useSchedules", "useInternal", "useKanban", "useOpenAi", "useIntegrations") FROM stdin;
1	Plano 1	10	10	10	30	2025-07-29 09:11:13.302+02	2025-07-29 09:11:13.302+02	t	t	t	t	t	t	t	t
\.


--
-- Data for Name: Prompts; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Prompts" (id, name, "apiKey", prompt, "maxTokens", "maxMessages", temperature, "promptTokens", "completionTokens", "totalTokens", voice, "voiceKey", "voiceRegion", "queueId", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: QueueIntegrations; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."QueueIntegrations" (id, type, name, "projectName", "jsonContent", language, "createdAt", "updatedAt", "urlN8N", "companyId", "typebotExpires", "typebotKeywordFinish", "typebotSlug", "typebotUnknownMessage", "typebotDelayMessage", "typebotKeywordRestart", "typebotRestartMessage") FROM stdin;
\.


--
-- Data for Name: QueueOptions; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."QueueOptions" (id, title, message, option, "queueId", "parentId", "createdAt", "updatedAt", "mediaName", "mediaPath") FROM stdin;
\.


--
-- Data for Name: Queues; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Queues" (id, name, color, "greetingMessage", "createdAt", "updatedAt", "companyId", schedules, "outOfHoursMessage", "orderQueue", "mediaName", "mediaPath", "integrationId", "promptId") FROM stdin;
\.


--
-- Data for Name: QuickMessages; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."QuickMessages" (id, shortcode, message, "companyId", "createdAt", "updatedAt", "userId", "mediaPath", "mediaName", geral) FROM stdin;
\.


--
-- Data for Name: Schedules; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Schedules" (id, body, "sendAt", "sentAt", "contactId", "ticketId", "userId", "companyId", "createdAt", "updatedAt", status, "queueId", "whatsappId", geral, "mediaName", "mediaPath", "repeatEvery", "repeatCount", "selectDaysRecorrenci") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."SequelizeMeta" (name) FROM stdin;
20200717133431-add-uuid-ossp.js
20200717133438-create-users.js
20200717144403-create-contacts.js
20200717145643-create-tickets.js
20200717151645-create-messages.js
20200717170223-create-whatsapps.js
20200723200315-create-contacts-custom-fields.js
20200723202116-add-email-field-to-contacts.js
20200730153237-remove-user-association-from-messages.js
20200730153545-add-fromMe-to-messages.js
20200813114236-change-ticket-lastMessage-column-type.js
20200901235509-add-profile-column-to-users.js
20200903215941-create-settings.js
20200904220257-add-name-to-whatsapp.js
20200906122228-add-name-default-field-to-whatsapp.js
20200906155658-add-whatsapp-field-to-tickets.js
20200919124112-update-default-column-name-on-whatsappp.js
20200927220708-add-isDeleted-column-to-messages.js
20200929145451-add-user-tokenVersion-column.js
20200930162323-add-isGroup-column-to-tickets.js
20200930194808-add-isGroup-column-to-contacts.js
20201004150008-add-contactId-column-to-messages.js
20201004155719-add-vcardContactId-column-to-messages.js
20201004955719-remove-vcardContactId-column-to-messages.js
20201026215410-add-retries-to-whatsapps.js
20201028124427-add-quoted-msg-to-messages.js
20210108001431-add-unreadMessages-to-tickets.js
20210108164404-create-queues.js
20210108164504-add-queueId-to-tickets.js
20210108174594-associate-whatsapp-queue.js
20210108204708-associate-users-queue.js
20210109192513-add-greetingMessage-to-whatsapp.js
20210109192514-create-companies-table.js
20210109192515-add-column-companyId-to-Settings-table.js
20210109192516-add-column-companyId-to-Users-table.js
20210109192517-add-column-companyId-to-Contacts-table.js
20210109192518-add-column-companyId-to-Messages-table.js
20210109192519-add-column-companyId-to-Queues-table.js
20210109192520-add-column-companyId-to-Whatsapps-table.js
20210109192521-add-column-companyId-to-Tickets-table.js
20210109192522-create-plans-table.js
20210109192523-add-column-planId-to-Companies.js
20210109192523-add-column-status-and-schedules-to-Companies.js
20210109192523-create-ticket-notes.js
20210109192524-create-quick-messages.js
20210109192525-add-column-complationMessage-to-whatsapp.js
20210109192526-add-column-outOfHoursMessage-to-whatsapp .js
20210109192527-add-column-super-to-Users-table.js
20210109192528-change-column-message-to-quick-messages-table.js
20210109192529-create-helps.js
20210109192530-add-unique-constraint-to-Contacts-table.js
20210109192531-create-TicketTracking-table.js
20210109192532-add-column-online-to-Users-table.js
20210109192533-create-UserRatings-table.js
20210109192534-add-rated-to-TicketTraking.js
20210109192535-add-column-ratingMessage-to-whatsapp.js
20210109192536-add-unique-constraint-to-Tickets-table.js
20210818102606-add-uuid-to-tickets.js
20210818102607-remove-unique-indexes-to-Queues-table.js
20210818102608-add-unique-indexes-to-Queues-table.js
20210818102609-add-token-to-Whatsapps.js
20211205164404-create-queue-options.js
20211212125704-add-chatbot-to-tickets.js
20211227010200-create-schedules.js
20220115114088-add-column-userId-to-QuickMessages-table.js
20220117130000-create-tags.js
20220117134400-associate-tickets-tags.js
20220122160900-add-status-to-schedules.js
20220220014719-add-farewellMessage-to-whatsapp.js
20220221014717-add-provider-whatsapp.js
20220221014718-add-remoteJid-messages.js
20220221014719-add-jsonMessage-messages.js
20220221014720-add-participant-messages.js
20220221014721-create-baileys.js
20220315110000-create-ContactLists-table.js
20220315110001-create-ContactListItems-table.js
20220315110002-create-Campaigns-table.js
20220315110004-create-CampaignSettings-table.js
20220315110005-remove-constraint-to-Settings.js
20220321130000-create-CampaignShipping.js
20220404000000-add-column-queueId-to-Messages-table.js
20220406000000-add-column-dueDate-to-Companies.js
20220406000001-add-column-recurrence-to-Companies.js
20220411000000-add-column-startTime-and-endTime-to-Queues.js
20220411000001-remove-column-startTime-and-endTime-to-Queues.js
20220411000002-add-column-schedules-and-outOfHoursMessage-to-Queues.js
20220411000003-create-table-Announcements.js
20220425000000-create-table-Chats.js
20220425000001-create-table-ChatUsers.js
20220425000002-create-table-ChatMessages.js
20220512000001-create-Indexes.js
20220512000002-create-subscriptions.js
20220512000003-create-invoices.js
20220723000001-add-mediaPath-to-quickmessages.js
20220723000002-add-mediaName-to-quickemessages.js
20221229000000-add-column-number-to-Whatsapps.js
20222016014720-create-baileys-chats.js
20222016014721-create-baileys-chats Messages.js
20230106164900-add-useCampaigns-Plans.js
20230106164900-add-useExternalApi-Plans.js
20230106164900-add-useInternalChat-Plans.js
20230106164900-add-useSchedules-Plans.js
20230127091500-add-column-active-to-Contacts.js
20230303223001-add-amountUsedBotQueues-to-tickets.js
20230417203900-add-allTickets-user.js
20230603212335-create-QueueIntegrations.js
20230603212337-add-urlN8N-QueueIntegrations.js
20230623095932-add-whatsapp-to-user.js
20230623133903-add-chatbotAt-ticket-tracking.js
20230628134807-add-orderQueue-Queue.js
20230711094417-add-column-companyId-to-QueueIntegrations-table.js
20230711111701-add-sendIdQueue-to-whatsapp.js
20230714113901-create-Files.js
20230714113902-create-fileOptions.js
20230717113705-add-isEdited-to-messages.js
20230723300999-add-queueId-to-Schedules.js
20230723301000-add-whatsappId-to-Schedules.js
20230723301001-add-kanban-to-Tags.js
20230723614328-add-geral-schedules.js
20230801081907-add-collumns-Ticket.js
20230805555699-add-useInternal-Plans.js
20230813114236-change-ticket-lastMessage-column-type.js
20230824082607-add-mediaType-FilesOptions.js
20230828143411-add-Integrations-to-tickets.js
20230828144000-create-prompts.js
20230828144100-add-column-promptid-into-whatsapps.js
20230831093000-add-useKanban-Plans.js
20230918122800-add-media-to-Queues.js
20230918142800-add-media-to-QueueOptions.js
20230922212337-add-integrationId-Queues.js
20230924212337-add-fileListId-Campaigns.js
20231111185822-add_reset_password_column.js
20231117000001-add-mediaName-to-schedules.js
20231117000001-add-mediaPath-to-schedules.js
20231127113000-add-columns-Plans.js
20231214143411-add-columns-to-whatsapps.js
20231214143411-add-promptId-to-tickets.js
20231218160937-add-columns-QueueIntegrations.js
20231220192536-add-unique-constraint-to-tickets-table.js
20231220223517-add-column-whatsappId-to-Contacts.js
20232016014719-add-transferTime-and-queueIdTransfer.js
20231128123537-add-typebot-QueueIntegrations.js
20231202143411-add-typebotSessionId-to-tickets.js
20231207080337-add-typebotDelayMessage-QueueIntegrations.js
20231207085011-add-typebotStatus-to-tickets.js
20231214092337-add-promptId-Queues.js
20240106050759-add-columns-to-schedules.js
20240522165800-add-disablebot-to-contact.js
20240620232001-remove-unique-constraint-from-queueintegrations.js
20240723000002-add-geral-to-quickemessages.js
20240815183416-add-reactions-to-messages.js
20240911143705-add-isForwarded-to-messages.js
20240914200100-whatsapps-change-unique-name.js
\.


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Settings" (key, value, "createdAt", "updatedAt", "companyId", id) FROM stdin;
chatBotType	text	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	1
sendGreetingAccepted	disabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	2
sendMsgTransfTicket	disabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	3
sendGreetingMessageOneQueues	disabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	4
userRating	disabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	5
scheduleType	queue	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	6
CheckMsgIsGroup	enabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	7
call	disabled	2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	8
ipixc		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	9
tokenixc		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	10
ipmkauth		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	11
clientidmkauth		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	12
clientsecretmkauth		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	13
asaas		2025-07-29 09:11:13.35+02	2025-07-29 09:11:13.35+02	1	14
allTicket	disabled	2025-07-29 09:11:13.355+02	2025-07-29 09:11:13.355+02	\N	15
\.


--
-- Data for Name: Subscriptions; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Subscriptions" (id, "isActive", "expiresAt", "userPriceCents", "whatsPriceCents", "lastInvoiceUrl", "lastPlanChange", "companyId", "providerSubscriptionId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Tags; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Tags" (id, name, color, "companyId", "createdAt", "updatedAt", kanban) FROM stdin;
\.


--
-- Data for Name: TicketNotes; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."TicketNotes" (id, note, "userId", "contactId", "ticketId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTags; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."TicketTags" ("ticketId", "tagId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTraking; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."TicketTraking" (id, "ticketId", "companyId", "whatsappId", "userId", "createdAt", "updatedAt", "queuedAt", "startedAt", "finishedAt", "ratingAt", rated, "chatbotAt") FROM stdin;
1	1	1	1	1	2025-07-29 09:24:39.008+02	2025-07-29 09:24:59.622+02	\N	2025-07-29 09:24:52.324+02	2025-07-29 09:24:59.607+02	\N	f	\N
\.


--
-- Data for Name: Tickets; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Tickets" (id, status, "lastMessage", "contactId", "userId", "createdAt", "updatedAt", "whatsappId", "isGroup", "unreadMessages", "queueId", "companyId", uuid, chatbot, "queueOptionId", "amountUsedBotQueues", "fromMe", "useIntegration", "integrationId", "typebotSessionId", "typebotStatus", "promptId") FROM stdin;
1	closed	oi	1	1	2025-07-29 09:24:38.998+02	2025-07-29 09:24:59.609+02	1	f	0	\N	1	fe2f9cf4-5587-4eb0-9665-a83bba323f61	f	\N	0	f	f	\N	\N	f	\N
\.


--
-- Data for Name: UserQueues; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."UserQueues" ("userId", "queueId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserRatings; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."UserRatings" (id, "ticketId", "companyId", "userId", rate, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Users" (id, name, email, "passwordHash", "createdAt", "updatedAt", profile, "tokenVersion", "companyId", super, online, "allTicket", "whatsappId", "resetPassword") FROM stdin;
1	FlexIot	flexiotbr@gmail.com	$2a$08$ONM86oRd/yaAtEE1mTXZ0.GHtw4mZq6.i7bUu9BhcmOTazgM2D3Oq	2025-07-29 09:11:13.344+02	2025-07-29 09:30:00.075+02	admin	0	1	t	f	desabled	\N	\N
\.


--
-- Data for Name: WhatsappQueues; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."WhatsappQueues" ("whatsappId", "queueId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Whatsapps; Type: TABLE DATA; Schema: public; Owner: botflex
--

COPY public."Whatsapps" (id, session, qrcode, status, battery, plugged, "createdAt", "updatedAt", name, "isDefault", retries, "greetingMessage", "companyId", "complationMessage", "outOfHoursMessage", "ratingMessage", token, "farewellMessage", provider, number, "sendIdQueue", "promptId", "integrationId", "maxUseBotQueues", "expiresInactiveMessage", "expiresTicket", "timeUseBotQueues", "transferQueueId", "timeToTransfer") FROM stdin;
1	{"creds":{"noiseKey":{"private":{"type":"Buffer","data":"KEXISzZWkGhtDuTFu2IyT8yMcsulBI/XdP6PnPoL2n8="},"public":{"type":"Buffer","data":"pkgF5Lug43LuqYj42cCe7RBSQzpIL1veexVvdp/DuBM="}},"pairingEphemeralKeyPair":{"private":{"type":"Buffer","data":"aH/H+x6yeNWmyiXNyp3VxNDNm2/1PfksBbe6PxEU1U0="},"public":{"type":"Buffer","data":"XBxZeCXmkKWZz//mBdzFJr0ENyhl3dQpN/yotg990mQ="}},"signedIdentityKey":{"private":{"type":"Buffer","data":"4LLkdtzp8A6BAcC6Pys/mpmSXThHpukqFVtJNd6ieX8="},"public":{"type":"Buffer","data":"uF5XVAS+mqERzCMZ138fWI5aLsd0n7b3JoF/s9C8mA4="}},"signedPreKey":{"keyPair":{"private":{"type":"Buffer","data":"WKdOBnrvf0WN0urgf31hf2zGukVZUyeZRUrD3HAD6ns="},"public":{"type":"Buffer","data":"50dYbJHJLcm9TNBvbXf6cIrA8SjjeIPFPJkktwmfMXk="}},"signature":{"type":"Buffer","data":"PQ9rjUaapQnUKWZR5ta0N+sLkvSKmZU0opBDQaP7uLgV5BGMH9/9pZOI4dCqyj9H2/htFmtdNhc00fpGcpOzgQ=="},"keyId":1},"registrationId":204,"advSecretKey":"ruUnMwua/5S5QN7cUKwFXL81OPkmvssW2Yjj420OlX0=","processedHistoryMessages":[{"key":{"remoteJid":"551151995306@s.whatsapp.net","fromMe":true,"id":"089B1E01B5C06A71C6500F8BB545E0F6"},"messageTimestamp":1753773861},{"key":{"remoteJid":"551151995306@s.whatsapp.net","fromMe":true,"id":"E799549A1EB509BC30E1787AD7D970D8"},"messageTimestamp":1753773861},{"key":{"remoteJid":"551151995306@s.whatsapp.net","fromMe":true,"id":"3C65BD2E363F26F36D99CE8E93C61829"},"messageTimestamp":1753773866}],"nextPreKeyId":31,"firstUnuploadedPreKeyId":31,"accountSyncCounter":1,"accountSettings":{"unarchiveChats":false},"registered":false,"account":{"details":"CLvlv/MEEJ7uocQGGAggACgA","accountSignatureKey":"u+/0dG6Rhb3zg5y6vdvyxBQZSK++ZfGCcAWWTpuvzxI=","accountSignature":"unQgR3Nzkp5c8G0y2hwX8SzWpPLMos8ON/II2fGs2trRMwWzyA6C3vkgaID5kxKqmwF+PHrZlgDJ3vn6rS0vDQ==","deviceSignature":"W6aNA+U9OIi1IjtvPIhb2DrG91ZoImG3tnX4SKOx1AfCEWTPNY3R1OkeGsvYvi8r0wI27mh4vmdWSVvdA9Wugg=="},"me":{"id":"551151995306:6@s.whatsapp.net","name":"FlexIot Soluções","lid":"69377076531240:6@lid"},"signalIdentities":[{"identifier":{"name":"551151995306:6@s.whatsapp.net","deviceId":0},"identifierKey":{"type":"Buffer","data":"Bbvv9HRukYW984Ocur3b8sQUGUivvmXxgnAFlk6br88S"}}],"platform":"smba","routingInfo":{"type":"Buffer","data":"CAkICw=="},"lastAccountSyncTimestamp":1753773859,"lastPropHash":"2DlyAg","myAppStateKeyId":"AAAAAAHZ"},"keys":{"preKeys":{"1":{"private":{"type":"Buffer","data":"UJ4iFcJwnF3SRp93c3p20CD6t8pkNrB8+0b978UFkV8="},"public":{"type":"Buffer","data":"WdYXzfv6+PQdgbN9Z6yLE7phpTS92c6ZcJedu4NryGQ="}},"2":{"private":{"type":"Buffer","data":"KJHp6Bs7h+dqYmoBBEzwLNb7TMiks98XBckPM6hdlV0="},"public":{"type":"Buffer","data":"c49vw8rx9WnVtFldTNl5Uwekf42wQNn7DPwwEhL8Qwk="}},"3":{"private":{"type":"Buffer","data":"6LGLkMcnO5fQoHHG4gEBhgjt3BXZPh/sEmTFjyNLk3E="},"public":{"type":"Buffer","data":"S9Hbm0pQa1LKYzlPrU1TFYXtXsKOBidGCu+e7Ovc2mU="}},"4":{"private":{"type":"Buffer","data":"uE4vURTR/AWfkiP1FsfFUH60ZuNPZUIExPVyZ6gM/08="},"public":{"type":"Buffer","data":"Xo953w1rl0qIb3qcsVFgWsz+cdwdmPs22hwMV5aoUz8="}},"5":{"private":{"type":"Buffer","data":"2NuRpi4+7RqfPSqTMNrXALel1Rlabb/5It17xY0VpUg="},"public":{"type":"Buffer","data":"FWtlDQHU2vVg+M10ZmGM+UtneZ/rnBaXCAXaqgQaxFI="}},"6":{"private":{"type":"Buffer","data":"6Nonav55pqmbH/sDbGsnlwZY9b+g8oXHCbH+E1TsnEI="},"public":{"type":"Buffer","data":"ruWazSOZvHWMIH2hzjNpAmEfmfK/lRGZtoBKhmNGtTg="}},"7":{"private":{"type":"Buffer","data":"GM4pHt7HhVJo4WWIZ77MA2NAvqEaZP776Qa3MfyQS1A="},"public":{"type":"Buffer","data":"YK8St3XBzAXVKCG8WXVqwbaIAFRcjP9G1gmfE72eWBg="}},"8":{"private":{"type":"Buffer","data":"4BmBajlG5Az+UNLKPSpSjYjNudlqHAj/XB1O5kBwgXc="},"public":{"type":"Buffer","data":"cHIZyaL8tLJwz6XOaH+to14YW9VoFl0Ar7gHuTVRhC0="}},"9":null,"10":{"private":{"type":"Buffer","data":"oG+N9rz15FllxbX/T0hkfRt1S76hbSO33wTtVoy4lX4="},"public":{"type":"Buffer","data":"peo0Ix+2q422gD/zaxMLBP5jPR+QvcS+WOGEyoRSoSc="}},"11":{"private":{"type":"Buffer","data":"MCBxHu6UitjW7XDbka3562i6UU1j1IdfnJzB4ASIbko="},"public":{"type":"Buffer","data":"H6CF4/zxFUCRoj9VlQF2E/LyyJiGQthONmCr7+dghB4="}},"12":{"private":{"type":"Buffer","data":"KATI+3aKaSGoTH02+wRxt1OCQvE+oFl1ewNNAk+L/2k="},"public":{"type":"Buffer","data":"OL90mHoSgxeFtQ9chkx5sIpSKdLb3YH7d+A/WfpMs0U="}},"13":{"private":{"type":"Buffer","data":"YC5TxAPDi5z3ZIpPE2Uh7xkPw2uAAYlZHggwjozH3nI="},"public":{"type":"Buffer","data":"uKxs++L6Cc/zYyMOGiwwpsjYyw2NZyjDZQ37zrWTSig="}},"14":{"private":{"type":"Buffer","data":"AM5Y1prnGY8pfsAqDGn1+F7jClanpp2Oj2xnSR8I+2k="},"public":{"type":"Buffer","data":"uYVPs/a+0twalx7RGl2/oSufkIEUTYSe83PdBOXrb24="}},"15":{"private":{"type":"Buffer","data":"YHHxdZ/Db8gc8/LWJomKPpwyHellk7edleesJdtLR2I="},"public":{"type":"Buffer","data":"0pGAbyHxaTB5E9zJUXov4P1jc/z0MK4IaCgc95g6jFk="}},"16":{"private":{"type":"Buffer","data":"qAxaaZwaKK1sAPivx6eNhV9tjWoXKPRJcN0+U/ytt28="},"public":{"type":"Buffer","data":"pB6N8Mu36WWQkpTsm1vrRIHmL2AxltB1PUqEwuqNYEg="}},"17":{"private":{"type":"Buffer","data":"AAKjmbUNFdkzEpVzRW1246CTk1DdgMkTLAQGBTQYXlA="},"public":{"type":"Buffer","data":"qD/32E5qaDYL4yymPjaZTsSslUk2W3AGo4oTY5iO/jk="}},"18":{"private":{"type":"Buffer","data":"UCbuCos/QMaLxV2atuR1JamI6x/SsFr/G5z/9futJFU="},"public":{"type":"Buffer","data":"fC7clpeccMsR/t7FMruBTlZewNez3LqYzuT4TvvYMD4="}},"19":{"private":{"type":"Buffer","data":"AJHYgpNjKe46wr8qtKFQRGzvLDivHblphKHsz001EnI="},"public":{"type":"Buffer","data":"RleGjHj9hAr67VAK8Zw0FJw9vCeJ4QAUviXxJu+GIH4="}},"20":{"private":{"type":"Buffer","data":"EA5/aIvfq+SkzW8lAijsjIlS+Rzu+NziVjRgd6GgkVU="},"public":{"type":"Buffer","data":"KXzdXdXECVpUveq5o1je/OgPEbE8zJGoFqYE0bdQcHw="}},"21":{"private":{"type":"Buffer","data":"+PbnbmzhoWX1kb3dSHJJ55ZsyX7WvCwTKuIjBESjuHc="},"public":{"type":"Buffer","data":"mIfoZwP6io+QdsFglAcwDaSnu1Sc1v7eVu9f96nRa3Q="}},"22":{"private":{"type":"Buffer","data":"yAHNZT1FD7t99a1hFfQujw6k+GcNszUTunYFTQvQa1c="},"public":{"type":"Buffer","data":"nsdKwwlFeDo1C6jS5xdFVrtFDuUoqCBecacHYE0YsRg="}},"23":{"private":{"type":"Buffer","data":"gBKJ7Tyhz2h2hU0qKQ+0PSNMSWjk41O8yEWaKeoBeX0="},"public":{"type":"Buffer","data":"UekOWEtnyahRX38ePFFUBVzJoFYNrtbR8szRw4ltqlM="}},"24":{"private":{"type":"Buffer","data":"EN1imhMTDFyJ0fbhquOhaLSPgCo88wNX1Lw/nt1jH1Q="},"public":{"type":"Buffer","data":"t4HGOKLx3UKudfi5yECLuO7a2hI2j5eqaHtWVHzo3EE="}},"25":{"private":{"type":"Buffer","data":"YKSt4A+c2HiDJmvHuaVVhB45oqNsI6Pf9PPMgx7sa0c="},"public":{"type":"Buffer","data":"1w+vhLO8uGHEqpumo6DDBd0kO6bFxb8YhePfr4l7JhQ="}},"26":{"private":{"type":"Buffer","data":"wLQh8qP4f3LXQh09Qzg+PdD/mWi33vXtY4mOVVAXtXs="},"public":{"type":"Buffer","data":"A5re+Lk5BrN0yfcQiIkXx3i2mUDMDjKdU3KHZeavtGo="}},"27":{"private":{"type":"Buffer","data":"aO0MVajp/QFZQ2lO/CCXns2hpgtgCS612Bnlw2o28Hw="},"public":{"type":"Buffer","data":"4IgaJ8TGZIYvadjBVu1w45IgdTPxNXfyIeOeAc18d3U="}},"28":{"private":{"type":"Buffer","data":"ENRisgwtmHFN+v5SROkzzFUjL8gsdu/VDt2WVc0cYFc="},"public":{"type":"Buffer","data":"i6S+NZ2gXnfpkrsOAE0E9ONJRA6Y54NaQHf8aAKArj4="}},"29":{"private":{"type":"Buffer","data":"aMMEMZz4/PcH7VFVklUlSNvy0ccgIOiw2nME4/6YREg="},"public":{"type":"Buffer","data":"5TEaC98Z8C0Qnt/giR8oKcGSSMyeZ0rlJ8PKCV+lI2Y="}},"30":{"private":{"type":"Buffer","data":"2JmjrF0LjJC8xnGu1su5UIZU7xknLY23LEy0Z326b1o="},"public":{"type":"Buffer","data":"aHjxOHvnLea97SbV66XzT8oD1nyWLx4zsA43vLdxmgk="}}},"sessions":{"551151995306.0":{"_sessions":{"BY26ARAoZ12jVaZAjDzsA7dfPtd5J2lzHaoZHoOgQ6dF":{"registrationId":1010734035,"currentRatchet":{"ephemeralKeyPair":{"pubKey":"BUL8N9FycMpQRsz7Qc4DW1QWf2HTZWPRwWfw2FoliC9a","privKey":"wIrvJxPW7tf9sGb3p/4t/Caek29JLK8mJb/cwB0AfXI="},"lastRemoteEphemeralKey":"BXbqVd+tIb9cQtrCz9hluZy+MBw3Gy/p5wJA8FezYWw4","previousCounter":0,"rootKey":"QbFtZUairOeStXtCgzbaAG85WzqA4x7D9nTzxu7V7Yg="},"indexInfo":{"baseKey":"BY26ARAoZ12jVaZAjDzsA7dfPtd5J2lzHaoZHoOgQ6dF","baseKeyType":2,"closed":-1,"used":1753773860983,"created":1753773860983,"remoteIdentityKey":"Bbvv9HRukYW984Ocur3b8sQUGUivvmXxgnAFlk6br88S"},"_chains":{"BXbqVd+tIb9cQtrCz9hluZy+MBw3Gy/p5wJA8FezYWw4":{"chainKey":{"counter":6,"key":"RnPyfaoeAucg8kp0iFaEiD2pdpiwnpHhzW2nYF7/kz0="},"chainType":2,"messageKeys":{}},"BUL8N9FycMpQRsz7Qc4DW1QWf2HTZWPRwWfw2FoliC9a":{"chainKey":{"counter":-1,"key":"RbXYEi6vu/wwn6ws3FFj+rXSS4eEHiF76RwyAjpAK8U="},"chainType":1,"messageKeys":{}}}}},"version":"v1"},"558299923865.77":{"_sessions":{"BS9Qmwl3/fx0UvXmhT9+WBEjrdvt8NysLofif0i99Atf":{"registrationId":7730,"currentRatchet":{"ephemeralKeyPair":{"pubKey":"BX5R5LNQQafceWubaIDxtenYjRVmAWuWLv7b84JhEoMx","privKey":"4Hh6lBVcYuHKO5twxUVZSmJL1T/CIbk8k8cNK5GwYWc="},"lastRemoteEphemeralKey":"BXz5UlWNN9IYaH+ra6SKHvuZcWvSEL6S5RZAhYVWdH1m","previousCounter":0,"rootKey":"FML7uWUU5E1CLR4ZQqmv46P/47cpA+9IscLIuhxtMhk="},"indexInfo":{"baseKey":"BS9Qmwl3/fx0UvXmhT9+WBEjrdvt8NysLofif0i99Atf","baseKeyType":2,"closed":-1,"used":1753773878763,"created":1753773878763,"remoteIdentityKey":"BaHksvvrufCCpXLoi1Z4Mt3uCBJQvY8OKqUimuNkvS9m"},"_chains":{"BXz5UlWNN9IYaH+ra6SKHvuZcWvSEL6S5RZAhYVWdH1m":{"chainKey":{"counter":0,"key":"f8sGxmXUqXBohA1W7lhsj+DvK8V1m50frMm+9/i7Fhg="},"chainType":2,"messageKeys":{}},"BX5R5LNQQafceWubaIDxtenYjRVmAWuWLv7b84JhEoMx":{"chainKey":{"counter":-1,"key":"RRm89axMwnBzefcXsXUBgB5dNWlHOUj+PItmtkqMUr4="},"chainType":1,"messageKeys":{}}}}},"version":"v1"}},"appStateSyncKeys":{"AAAAAAHi":{"keyData":"35PWOfiDpQ7/c3cJWKxBeJcM3SNN9pQcbRVrJpQFmn8=","fingerprint":{"rawId":1315959483,"currentIndex":7,"deviceIndexes":[0,6,7]},"timestamp":"1753773838452"},"AAAAAAHg":{"keyData":"iwKC0FdF+GOjSf2hxa5Bdngs2z+QBMMdkZ/8IVg7a2M=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"1749160850507"},"AAAAAAHh":{"keyData":"nBNGJ2FZNUVO+i3lWmYGHz+t6oAx4u309fRSZYbFnaY=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"0"},"AAAAAAHW":{"keyData":"5ByK40Ww5R2D3y08tbe3EO/3apWK1kZVJSBKZcJ7UT8=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1725196731275"},"AAAAAAHX":{"keyData":"F1GvCVntuvQobuQRndlZkzXnohss+uTRB6nEHSj0vCE=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1727803909375"},"AAAAAAHU":{"keyData":"uQYxbNxD++ppC3jkRFYsfU9ywPkZDJu4LYCzEs4egJc=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1719968402165"},"AAAAAAHT":{"keyData":"OQ/tR10OQEaDSQZvtrbNg+yeeWaI/6zVxYlo/l1Shdo=","fingerprint":{"rawId":1315959483,"currentIndex":2,"deviceIndexes":[0,1]},"timestamp":"1719793498100"},"AAAAAAHR":{"keyData":"yGWTZqNLTE8lc7/HtPdZTIPK4sDScQqnnh4l2+rYzeI=","fingerprint":{"rawId":1315959483,"currentIndex":1,"deviceIndexes":[0,1]},"timestamp":"1716403963992"},"AAAAAAHe":{"keyData":"MT39VLGvre+UFumm84MVHzkWMXF9X0p+xzMNhKbO/gg=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"1743919207107"},"AAAAAAHf":{"keyData":"tP4C93W3G2sFwaLfaObcDtMb76eL0tpupY+Yk2nH7zE=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"1746550403547"},"AAAAAAHc":{"keyData":"DKR2D9D/DbzroJDwWZ1K50m7UHQzF7NOTF5hOv6GzmE=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"1738658695811"},"AAAAAAHd":{"keyData":"SfNFbQcc8wW6OaaiLkhtSh77fHIM1AXNNKpOdtgU2fM=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1]},"timestamp":"1741323720321"},"AAAAAAHa":{"keyData":"tIV2E61FqhojWzqRGOAPKPC4ljEWzzrUN38n0xDbz7s=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1735648188010"},"AAAAAAHb":{"keyData":"mhvnVJHadfRCa1GGD+KntHwTujZBWgvKx8XBzlDPYFM=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1738241295656"},"AAAAAAHY":{"keyData":"J6Px85DF7HL0j+C4Ilfy6/y80tzLZXveEda5YdXeFGs=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1730458238744"},"AAAAAAHZ":{"keyData":"8bRFRrcKAUVyqpupTtXVWdMUiNAVnZ68pPk7Rvy4O8o=","fingerprint":{"rawId":1315959483,"currentIndex":5,"deviceIndexes":[0,1,5]},"timestamp":"1733056038119"}},"appStateVersions":{"critical_unblock_low":null,"regular_high":{"version":5,"hash":{"type":"Buffer","data":"pL2K+TP3EAAhWz22Rr0qIdO9dIGr8EjJg8MmSUvFT42A01kOcpRQ+QGvUcw2EwlnCE1+F8izkN61MQIq0sgWFZA+WDOPoM0bNC68a5rhY7TRNhLmrCVzZa/Uc54sGS2XCxipCovJ93hMivVSMP7VwJcMeOo4OFlusHUfqt4f4Ic="},"indexValueMap":{"CC65WZpZdtLcHTsG07xrouV2/Gh7mQm/b/mYmdQk2xo=":{"valueMac":{"type":"Buffer","data":"+p2jVM8RuJdCZ0oMoEHpti1G79ZH+wW/1mlKMusXa6o="}},"Dt/curvINaDnAJnDZ9ld7pC59XkHqunk/WZQ4JHCRqE=":{"valueMac":{"type":"Buffer","data":"PMXKb9fI5x4hGsgGdoMe3nwWuiAuJFE3YMUrbQpDJTk="}},"kxHlRhI8e5SKa1MaKdDT4Fr+ykJjNnN0PGFUd9jx9GQ=":{"valueMac":{"type":"Buffer","data":"/c9hlyTep1LGNNm9vM1DeOW4lrQcpCnT8wUcXuI2fDA="}},"nHCVMDl0odZahy2Dt+2ImwBjVp12oqu4Q05aYztkYtk=":{"valueMac":{"type":"Buffer","data":"mMlMZELxZeKj8esD1TlcbCk3aJeEghr4xSDrACEKpKk="}},"CNxZ5QCmuOGVBUXInCPNbNjwbbNZKpbL3ZtnD1JYrQA=":{"valueMac":{"type":"Buffer","data":"zaD9Y9Vc/DdrpaFYJsSAOWVSI/6IiZlscgHyb9zz3IU="}}}},"critical_block":{"version":2,"hash":{"type":"Buffer","data":"y9srzgGHg7mErXSxpHlps4Fw/d+uFWvEQ2tuYkSM7cjPeSNm3TWwB0BZt869ThVOkrJc9yY+4qSm9AeRmbg/63xujHvpLBJX1kP4u+j7cuh2oKRCbHRneYVTllTi3KnwhcGcBnIglxTMhFpjzw+bn+Fj3cNi5cd6pP0tRJOHkKY="},"indexValueMap":{"caMnrjEZ+P7rhNDwpE+ajD6ZYvOWT+Ma5taQfTLwpYo=":{"valueMac":{"type":"Buffer","data":"OVoeALlrtv5yXGBgxy0E68AQIF2OrXEECFFfL40xhCE="}},"LIgF20uNHt73IE0b2jPak7dAS85un/gUNokRoREOLCE=":{"valueMac":{"type":"Buffer","data":"mUVZbgMZVlboZ699TImcZfiC3uX4MwSP1dd8xdbDWS4="}},"IBfcFVFlbj+J0XeYyiufjJbKFrayh/803xaJuBU4+WE=":{"valueMac":{"type":"Buffer","data":"TUNiYf/ab7ivGUacll5L7a1HqL/s89xZE5dsDkeIjss="}}}},"regular":{"version":26,"hash":{"type":"Buffer","data":"TqtmQjToJTJceUCiE/RF6uxgvFzAgcYpNnkh3iXKQ0NCoQjfbxaC97dAq8laaw15P+oTSYIjp9oaGsz+eslqGX9NYB2bfiEpNi008naER0egeVAx9rZpLXtOYwQMMmB5LGNB0yPp5BX+9z3hwg68sxeQCXsZtrABpW8IFMOlBVQ="},"indexValueMap":{"BgltHTR6P4XmRxgxdL3UtUfKgSKnJUfTF9by61h0AfQ=":{"valueMac":{"type":"Buffer","data":"DJ53BLw9ONdo9TrwvAmHEDGjiwI8WC+IrRv1ewRpT9g="}},"DZ7d0uxY4eSFIqR239GHvj+6jgwYtPe21WKpPBe8UC4=":{"valueMac":{"type":"Buffer","data":"fd7ifL/G4OaAt2iNQPxrfRKkfZCyktfO5uvaOU8fI6E="}},"HeJPsOBCK6jH3dIXL5sXzYEyS9iRFG4XX/BtFLxj0tc=":{"valueMac":{"type":"Buffer","data":"ypEPBm6gLpBpuxl1uj+1F3r8WNWiM7ucpjehIyNHUZ4="}},"IFatDIUCXd90f0NB7rhHl06B2ULNf2yrtKoEHLX32v8=":{"valueMac":{"type":"Buffer","data":"n8qb27W0U0L32fbvMhDiCzzdZQyPijxCTWaRC2maQSs="}},"UZP1ttLZOo+t4m7rj+/YwgKLEkZaN2v9SDPHnZ4bREk=":{"valueMac":{"type":"Buffer","data":"wMfv8WI74R78Vhs8XI2JxleZyN2GLWyCIQoVy3iBL3o="}},"bJAwx2s+DB+LQMRo71n1lQ0xy9Am1UG7Lvmk+1JMGK0=":{"valueMac":{"type":"Buffer","data":"QnkKJdgX3VubydnyMTXCi92RrWWLPeFakWveRl+hoWM="}},"eS7uRD5udcOmv0cuUlAr9tKgn6uSl/QX5D4lRSjcgEc=":{"valueMac":{"type":"Buffer","data":"HadePWe1mn71G7TvXTu8H4suLvreFDqbYIjWzfLtrhI="}},"gy6J3yH3H0uhMRxTm86eegPuo8+LPu++6B1OV6eRWA0=":{"valueMac":{"type":"Buffer","data":"grq4LSc4I4mxwe/QYnC2JQuSoJVTH6vUaYZWprVd6Ow="}},"rcEdxN7yVRzvfsehuf7gmOct2InBs0hUS45WmbpkV0Q=":{"valueMac":{"type":"Buffer","data":"mQayUamccwm6JlFZco+ImNoAnP13hXTcnim98n7zRjg="}},"w2IKLKjZyaevQ4DLVqzK0Us6q3WEzxxyNjq2xaKvhxQ=":{"valueMac":{"type":"Buffer","data":"h7YHl4bZdIJBiOajfCF0J5/KxbXpBlYtD7yYcGXmrh4="}},"yVnbpaGkAEy/SWr1xND5ukCNgpTQa50y8pI5rI/9LVU=":{"valueMac":{"type":"Buffer","data":"Xnt3KOo8xa0GK/USHNve7dDUk/eqdkSCortXwiecf1k="}},"3Y8SY4Ri7u2O9gVSMxD57HVG+HAmqSKECthqss+5hTI=":{"valueMac":{"type":"Buffer","data":"xt7iusYUf53A7sETHTHkgbFJDsJn7g/WBGCbHXiDGZE="}},"lz8lBtD10/+KBFi5A5d0g6b8QZDLCQFh9zU2TSCsQtk=":{"valueMac":{"type":"Buffer","data":"KA4R7AiyDColVdAR8L++fHTdnQaglP9K6BYS6Sv1m8o="}},"raNA9kLpAAtM7yOP6MP2o2JQNIESosCVTulEYVCmXf0=":{"valueMac":{"type":"Buffer","data":"SU7VPZfSpO5uHgoJykvb1faTO5jd8JBpkvOi7uyYfrM="}},"Iv/W0wdoafPjYHgdubZQuhKwuoI61a5om7GHVylV2cE=":{"valueMac":{"type":"Buffer","data":"+bUZZUL/kb46nbsjGD/2KqUqxlg/bUzq+/RVZYRdiY4="}},"CltWUIzPlSJqqYnAbTrhpiSHiSXqDVIvMVcMEi8aveU=":{"valueMac":{"type":"Buffer","data":"MwI/GirJb61VZ89rA6eGfEYEFqsLpPuxjpoT5BeqrzY="}},"Gbc0SH7/jyaSvEZuWwB4HyS7spPi4gN0TNMAbIHxiBw=":{"valueMac":{"type":"Buffer","data":"4eeVp0K8i3SvU3jpNuTK+qx6NUuREOBixfY2jTMA8J0="}},"MJ2PA+EXmJb8MUKstZvQmgqmiCs0zgQL/9zyDQ/Zkns=":{"valueMac":{"type":"Buffer","data":"Hc+tt+J9MRQmC55t6QkGmJBj6xCvgvDBxZ5a0FGWuNE="}}}},"regular_low":null}}}		CONNECTED	\N	\N	2025-07-29 09:22:12.332+02	2025-07-29 09:24:38.767+02	FlexIot	t	0		1						beta	551151995306	\N	\N	\N	3		0	0	\N	\N
\.


--
-- Name: Announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Announcements_id_seq"', 1, false);


--
-- Name: BaileysChats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."BaileysChats_id_seq"', 1, false);


--
-- Name: BaileysMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."BaileysMessages_id_seq"', 1, false);


--
-- Name: Baileys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Baileys_id_seq"', 1, false);


--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."CampaignSettings_id_seq"', 1, false);


--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."CampaignShipping_id_seq"', 1, false);


--
-- Name: Campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Campaigns_id_seq"', 1, false);


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."ChatMessages_id_seq"', 1, false);


--
-- Name: ChatUsers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."ChatUsers_id_seq"', 1, false);


--
-- Name: Chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Chats_id_seq"', 1, false);


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 1, true);


--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."ContactCustomFields_id_seq"', 1, false);


--
-- Name: ContactListItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."ContactListItems_id_seq"', 1, false);


--
-- Name: ContactLists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."ContactLists_id_seq"', 1, false);


--
-- Name: Contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Contacts_id_seq"', 1, true);


--
-- Name: FilesOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."FilesOptions_id_seq"', 1, false);


--
-- Name: Files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Files_id_seq"', 1, false);


--
-- Name: Helps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Helps_id_seq"', 1, false);


--
-- Name: Invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Invoices_id_seq"', 1, true);


--
-- Name: Plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Plans_id_seq"', 1, true);


--
-- Name: Prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Prompts_id_seq"', 1, false);


--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."QueueIntegrations_id_seq"', 1, false);


--
-- Name: QueueOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."QueueOptions_id_seq"', 1, false);


--
-- Name: Queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Queues_id_seq"', 1, false);


--
-- Name: QuickMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."QuickMessages_id_seq"', 1, false);


--
-- Name: Schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Schedules_id_seq"', 1, false);


--
-- Name: Settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Settings_id_seq"', 15, true);


--
-- Name: Subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Subscriptions_id_seq"', 1, false);


--
-- Name: Tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Tags_id_seq"', 1, false);


--
-- Name: TicketNotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."TicketNotes_id_seq"', 1, false);


--
-- Name: TicketTraking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."TicketTraking_id_seq"', 1, true);


--
-- Name: Tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Tickets_id_seq"', 1, true);


--
-- Name: UserRatings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."UserRatings_id_seq"', 1, false);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Users_id_seq"', 1, true);


--
-- Name: Whatsapps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: botflex
--

SELECT pg_catalog.setval('public."Whatsapps_id_seq"', 1, true);


--
-- Name: Announcements Announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_pkey" PRIMARY KEY (id);


--
-- Name: BaileysChats BaileysChats_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysChats"
    ADD CONSTRAINT "BaileysChats_pkey" PRIMARY KEY (id);


--
-- Name: BaileysMessages BaileysMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysMessages"
    ADD CONSTRAINT "BaileysMessages_pkey" PRIMARY KEY (id);


--
-- Name: Baileys Baileys_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Baileys"
    ADD CONSTRAINT "Baileys_pkey" PRIMARY KEY (id, "whatsappId");


--
-- Name: CampaignSettings CampaignSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_pkey" PRIMARY KEY (id);


--
-- Name: CampaignShipping CampaignShipping_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_pkey" PRIMARY KEY (id);


--
-- Name: Campaigns Campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessages ChatMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_pkey" PRIMARY KEY (id);


--
-- Name: ChatUsers ChatUsers_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_pkey" PRIMARY KEY (id);


--
-- Name: Chats Chats_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_pkey" PRIMARY KEY (id);


--
-- Name: Companies Companies_name_key; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_name_key" UNIQUE (name);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: ContactCustomFields ContactCustomFields_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_pkey" PRIMARY KEY (id);


--
-- Name: ContactListItems ContactListItems_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_pkey" PRIMARY KEY (id);


--
-- Name: ContactLists ContactLists_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_pkey" PRIMARY KEY (id);


--
-- Name: Contacts Contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_pkey" PRIMARY KEY (id);


--
-- Name: FilesOptions FilesOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_pkey" PRIMARY KEY (id);


--
-- Name: Files Files_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY (id);


--
-- Name: Helps Helps_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Helps"
    ADD CONSTRAINT "Helps_pkey" PRIMARY KEY (id);


--
-- Name: Invoices Invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_pkey" PRIMARY KEY (id);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: Plans Plans_name_key; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_name_key" UNIQUE (name);


--
-- Name: Plans Plans_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_pkey" PRIMARY KEY (id);


--
-- Name: Prompts Prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_pkey" PRIMARY KEY (id);


--
-- Name: QueueIntegrations QueueIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: QueueOptions QueueOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_pkey" PRIMARY KEY (id);


--
-- Name: Queues Queues_color_key; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_color_key" UNIQUE (color, "companyId");


--
-- Name: Queues Queues_name_key; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_name_key" UNIQUE (name, "companyId");


--
-- Name: Queues Queues_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_pkey" PRIMARY KEY (id);


--
-- Name: QuickMessages QuickMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_pkey" PRIMARY KEY (id);


--
-- Name: Schedules Schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: Subscriptions Subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_pkey" PRIMARY KEY (id);


--
-- Name: Tags Tags_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_pkey" PRIMARY KEY (id);


--
-- Name: TicketNotes TicketNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_pkey" PRIMARY KEY (id);


--
-- Name: TicketTraking TicketTraking_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_pkey" PRIMARY KEY (id);


--
-- Name: Tickets Tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_pkey" PRIMARY KEY (id);


--
-- Name: UserQueues UserQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserQueues"
    ADD CONSTRAINT "UserQueues_pkey" PRIMARY KEY ("userId", "queueId");


--
-- Name: UserRatings UserRatings_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: WhatsappQueues WhatsappQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."WhatsappQueues"
    ADD CONSTRAINT "WhatsappQueues_pkey" PRIMARY KEY ("whatsappId", "queueId");


--
-- Name: Whatsapps Whatsapps_pkey; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_pkey" PRIMARY KEY (id);


--
-- Name: Whatsapps company_name_constraint; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT company_name_constraint UNIQUE ("companyId", name);


--
-- Name: Tickets contactid_companyid_unique; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT contactid_companyid_unique UNIQUE ("contactId", "companyId", "whatsappId");


--
-- Name: Contacts number_companyid_unique; Type: CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT number_companyid_unique UNIQUE (number, "companyId");


--
-- Name: idx_cont_company_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_cont_company_id ON public."Contacts" USING btree ("companyId");


--
-- Name: idx_cpsh_campaign_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_cpsh_campaign_id ON public."CampaignShipping" USING btree ("campaignId");


--
-- Name: idx_ctli_contact_list_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_ctli_contact_list_id ON public."ContactListItems" USING btree ("contactListId");


--
-- Name: idx_ms_company_id_ticket_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_ms_company_id_ticket_id ON public."Messages" USING btree ("companyId", "ticketId");


--
-- Name: idx_sched_company_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_sched_company_id ON public."Schedules" USING btree ("companyId");


--
-- Name: idx_tg_company_id; Type: INDEX; Schema: public; Owner: botflex
--

CREATE INDEX idx_tg_company_id ON public."Tags" USING btree ("companyId");


--
-- Name: Announcements Announcements_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BaileysChats BaileysChats_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysChats"
    ADD CONSTRAINT "BaileysChats_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BaileysMessages BaileysMessages_baileysChatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysMessages"
    ADD CONSTRAINT "BaileysMessages_baileysChatId_fkey" FOREIGN KEY ("baileysChatId") REFERENCES public."BaileysChats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BaileysMessages BaileysMessages_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."BaileysMessages"
    ADD CONSTRAINT "BaileysMessages_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignSettings CampaignSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaigns"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."ContactListItems"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Campaigns Campaigns_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_fileListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_fileListId_fkey" FOREIGN KEY ("fileListId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ChatMessages ChatMessages_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatMessages ChatMessages_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Companies Companies_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plans"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ContactCustomFields ContactCustomFields_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactLists ContactLists_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Contacts Contacts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Contacts Contacts_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FilesOptions FilesOptions_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Files Files_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoices Invoices_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Messages Messages_quotedMsgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_quotedMsgId_fkey" FOREIGN KEY ("quotedMsgId") REFERENCES public."Messages"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prompts Prompts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id);


--
-- Name: Prompts Prompts_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id);


--
-- Name: QueueIntegrations QueueIntegrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QueueOptions QueueOptions_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."QueueOptions"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QueueOptions QueueOptions_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Queues Queues_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QuickMessages QuickMessages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QuickMessages QuickMessages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Schedules Schedules_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Settings Settings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Subscriptions Subscriptions_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tags Tags_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketNotes TicketNotes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketTags TicketTags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tags"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTags TicketTags_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTraking TicketTraking_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tickets Tickets_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id);


--
-- Name: Tickets Tickets_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_queueOptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueOptionId_fkey" FOREIGN KEY ("queueOptionId") REFERENCES public."QueueOptions"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Tickets Tickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: Users Users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Users Users_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: botflex
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

